<?php

$conn=mysqli_connect("localhost","root","","speed_age");

if(!$conn)
{
	echo 'could not connect'.mysqli_error();
}






?>
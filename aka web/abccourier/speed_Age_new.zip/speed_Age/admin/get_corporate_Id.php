
<?php
include('header.php');
include('sidebar.php');
	
?>

<div id="page-wrapper" style="overflow: scroll;
    height: 509px;">
	<div class="graphs">
		<h3 class="blank1">Get Corporate id </h3>
		<div class="col-sm-12">
			<div class="col-sm-2">
			</div>
			<div class="col-sm-2">
			</div>
		</div>
		<div class="tab-content">
			<div class="tab-pane active" id="horizontal-form">
				<p>Dear speed courier your  Corporate  Id is (CIDooo1).<br/>
					please provide this Corporate Id  in your  transactions  to avail attractive discounts.
				</p>
			</div>
		</div>
		<!--body wrapper start-->
	</div>
	<!--body wrapper end-->
</div>

<?php
include('footer.php');
?>